



function search() {
  let searchTerm = document.getElementById("search-bar").value;
  console.log("Search term:", searchTerm);
  // logic to perform
  if (searchTerm === 'iphone') {
      window.location.href = "#Logo";  }
  if (searchTerm === 'tree') {
    window.location.href = "https://www.google.com/search?q=christmas+tree";
  }
}
function addToCart() {
  console.log("Item added to cart");
}